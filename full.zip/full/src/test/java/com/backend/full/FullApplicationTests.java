package com.backend.full;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullApplicationTests {

	@Test
	void contextLoads() {
	}

}
